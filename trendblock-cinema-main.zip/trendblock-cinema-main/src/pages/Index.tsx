import { Layout } from '@/components/Layout';
import { HeroBanner } from '@/components/HeroBanner';
import { MovieRow } from '@/components/MovieRow';
import { SearchBar } from '@/components/SearchBar';
import { AdBanner } from '@/components/AdBanner';
import { useState, useEffect } from 'react';
import { LayoutGrid, Flame, Zap, Tv, Film, Clock, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Movie } from '@/types/movie';
import { cn } from '@/lib/utils';

const Index = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [allMovies, setAllMovies] = useState<Movie[]>([]);
  const [todaysPicks, setTodaysPicks] = useState<Movie[]>([]);
  const [currentPickIndex, setCurrentPickIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch movies from database
  useEffect(() => {
    const fetchMovies = async () => {
      try {
        // Fetch all movies ordered by created_at (newest first)
        const { data: movies, error } = await supabase
          .from('movies')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) {
          console.error('Error fetching movies:', error);
          return;
        }

        if (movies && movies.length > 0) {
          // Map database movies to Movie type
          const mappedMovies: Movie[] = movies.map((m) => ({
            id: m.id,
            title: m.title,
            description: m.description || '',
            thumbnail: m.poster_url || '/placeholder.svg',
            videoUrl: m.video_url || undefined,
            trailerUrl: m.trailer_url || undefined,
            category: (m.category === 'series' ? 'series' : 'movie') as 'movie' | 'series',
            genre: m.genre || [],
            releaseYear: m.release_year || 2024,
            rating: m.rating || 0,
            duration: m.duration || undefined,
            is4K: m.is_4k || false,
          }));

          setAllMovies(mappedMovies);

          // Find today's picks (up to 5)
          const picks = movies
            .filter((m) => m.is_todays_pick)
            .slice(0, 5)
            .map((pick) => ({
              id: pick.id,
              title: pick.title,
              description: pick.description || '',
              thumbnail: pick.poster_url || '/placeholder.svg',
              videoUrl: pick.video_url || undefined,
              trailerUrl: pick.trailer_url || undefined,
              category: (pick.category === 'series' ? 'series' : 'movie') as 'movie' | 'series',
              genre: pick.genre || [],
              releaseYear: pick.release_year || 2024,
              rating: pick.rating || 0,
              duration: pick.duration || undefined,
              is4K: pick.is_4k || false,
            }));

          setTodaysPicks(picks);
        }
      } catch (err) {
        console.error('Error:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchMovies();
  }, []);

  // Auto-rotate hero carousel
  useEffect(() => {
    if (todaysPicks.length > 1) {
      const interval = setInterval(() => {
        setCurrentPickIndex((prev) => (prev + 1) % todaysPicks.length);
      }, 6000);
      return () => clearInterval(interval);
    }
  }, [todaysPicks.length]);

  const filteredMovies = searchQuery 
    ? allMovies.filter(m => 
        m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.genre.some(g => g.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : null;

  // Filter movies by category
  const seriesMovies = allMovies.filter(m => m.category === 'series');
  const animeMovies = allMovies.filter(m => m.genre?.includes('Anime') || m.genre?.includes('Animation'));
  const trendingMovies = allMovies.filter(m => m.rating >= 8.0).slice(0, 10);
  const actionMovies = allMovies.filter(m => m.genre?.includes('Action'));

  const nextPick = () => setCurrentPickIndex((prev) => (prev + 1) % todaysPicks.length);
  const prevPick = () => setCurrentPickIndex((prev) => (prev - 1 + todaysPicks.length) % todaysPicks.length);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="animate-fade-in pb-24">
        {/* Today's Pick Hero Carousel */}
        {todaysPicks.length > 0 ? (
          <div className="relative">
            <HeroBanner movie={todaysPicks[currentPickIndex]} />
            
            {/* Carousel Controls - only show if multiple picks */}
            {todaysPicks.length > 1 && (
              <>
                <button
                  onClick={prevPick}
                  className="absolute left-6 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-background/50 backdrop-blur-sm flex items-center justify-center hover:bg-background/70 transition-colors"
                >
                  <ChevronLeft size={24} className="text-foreground" />
                </button>
                <button
                  onClick={nextPick}
                  className="absolute right-6 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-background/50 backdrop-blur-sm flex items-center justify-center hover:bg-background/70 transition-colors"
                >
                  <ChevronRight size={24} className="text-foreground" />
                </button>
                
                {/* Dots Indicator */}
                <div className="absolute bottom-20 left-1/2 -translate-x-1/2 flex gap-2 z-10">
                  {todaysPicks.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentPickIndex(index)}
                      className={cn(
                        "w-2 h-2 rounded-full transition-all",
                        index === currentPickIndex 
                          ? "bg-primary w-6" 
                          : "bg-foreground/30 hover:bg-foreground/50"
                      )}
                    />
                  ))}
                </div>
              </>
            )}
          </div>
        ) : allMovies.length > 0 ? (
          <HeroBanner movie={allMovies[0]} />
        ) : (
          <div className="mx-4 mt-4 rounded-2xl overflow-hidden bg-secondary aspect-[4/3] md:aspect-video flex items-center justify-center">
            <p className="text-muted-foreground">No movies available yet</p>
          </div>
        )}
        
        {/* Search Bar */}
        <SearchBar 
          value={searchQuery}
          onChange={setSearchQuery}
        />

        {/* Content */}
        {filteredMovies ? (
          <MovieRow 
            title={`Results for "${searchQuery}"`}
            movies={filteredMovies}
            showViewAll={false}
          />
        ) : (
          <>
            {/* Recents - Database movies sorted by newest */}
            {allMovies.length > 0 && (
              <MovieRow 
                title="RECENTS"
                movies={allMovies}
                icon={<Clock size={16} className="text-primary" />}
              />
            )}

            {/* First Sponsored Ad Banner - below Recents */}
            <div className="px-4 mb-6">
              <div className="w-full py-3 bg-gradient-to-r from-primary/20 via-primary/10 to-primary/20 border border-primary/30 rounded-lg pointer-events-none">
                <div className="flex items-center justify-center gap-2">
                  <Star size={14} className="text-primary" />
                  <span className="text-xs text-primary font-semibold tracking-wider">
                    SPONSORED CONTENT
                  </span>
                  <span className="px-2 py-0.5 bg-primary text-primary-foreground text-xs font-bold rounded">
                    AD
                  </span>
                </div>
              </div>
            </div>

            {/* Master Movies Section - All movies */}
            {allMovies.length > 0 && (
              <MovieRow 
                title="MASTER MOVIES"
                movies={allMovies.filter(m => m.category === 'movie')}
                icon={<Film size={16} className="text-primary" />}
              />
            )}

            {/* Global Series */}
            {seriesMovies.length > 0 && (
              <MovieRow 
                title="GLOBAL SERIES"
                movies={seriesMovies}
                icon={<Tv size={16} className="text-primary" />}
              />
            )}

            {/* Anime Hub */}
            {animeMovies.length > 0 && (
              <MovieRow 
                title="ANIME HUB"
                movies={animeMovies}
                icon={<LayoutGrid size={16} className="text-primary" />}
              />
            )}

            {/* Trending */}
            {trendingMovies.length > 0 && (
              <MovieRow 
                title="TRENDING NOW"
                movies={trendingMovies}
                icon={<Flame size={16} className="text-primary" />}
              />
            )}

            {/* Action Packed */}
            {actionMovies.length > 0 && (
              <MovieRow 
                title="ACTION PACKED"
                movies={actionMovies}
                icon={<Zap size={16} className="text-primary" />}
              />
            )}
          </>
        )}

        {/* Second Sponsored Ad Banner - bottom of page */}
        <div className="px-4 mb-6">
          <div className="w-full py-3 bg-gradient-to-r from-primary/20 via-primary/10 to-primary/20 border border-primary/30 rounded-lg pointer-events-none">
            <div className="flex items-center justify-center gap-2">
              <Star size={14} className="text-primary" />
              <span className="text-xs text-primary font-semibold tracking-wider">
                SPONSORED CONTENT
              </span>
              <span className="px-2 py-0.5 bg-primary text-primary-foreground text-xs font-bold rounded">
                AD
              </span>
            </div>
          </div>
        </div>

        {/* Bottom Ad Banner */}
        <AdBanner />
      </div>
    </Layout>
  );
};

export default Index;
