import { Movie } from '@/types/movie';
import { MovieCard } from './MovieCard';
import { ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface MovieRowProps {
  title: string;
  movies: Movie[];
  icon?: React.ReactNode;
  showViewAll?: boolean;
}

export const MovieRow = ({ title, movies, icon, showViewAll = true }: MovieRowProps) => {
  const navigate = useNavigate();

  return (
    <section className="py-4">
      <div className="flex items-center justify-between px-4 mb-3">
        <div className="flex items-center gap-2">
          {icon && (
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              {icon}
            </div>
          )}
          <h2 className="font-display text-lg tracking-wide text-foreground">
            {title}
          </h2>
        </div>
        
        {showViewAll && (
          <button 
            onClick={() => navigate('/categories')}
            className="flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-primary transition-colors"
          >
            VIEW ALL
            <ChevronRight size={14} />
          </button>
        )}
      </div>
      
      <div className="flex gap-3 overflow-x-auto scrollbar-hide px-4 pb-2">
        {movies.map((movie) => (
          <MovieCard 
            key={movie.id} 
            movie={movie}
            onClick={() => navigate(`/movie/${movie.id}`)}
          />
        ))}
      </div>
    </section>
  );
};
