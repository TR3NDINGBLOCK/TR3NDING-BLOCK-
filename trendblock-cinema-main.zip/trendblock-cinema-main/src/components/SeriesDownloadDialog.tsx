import { useState, useEffect } from 'react';
import { Download, X, Check, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface Episode {
  id: string;
  season_number: number;
  episode_number: number;
  title: string | null;
  duration: string | null;
  file_size_360p: string | null;
  file_size_480p: string | null;
  file_size_720p: string | null;
  file_size_1080p: string | null;
}

interface SeriesDownloadDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onDownload: (episodes: Episode[], quality: string) => void;
  movieId: string;
  movieTitle: string;
}

const QUALITY_OPTIONS = ['360p', '480p', '720p', '1080p'];

// Ad countdown times: 360p = 3 seconds, others = 10 seconds
const getAdCountdown = (quality: string) => quality === '360p' ? 3 : 10;

export const SeriesDownloadDialog = ({
  isOpen,
  onClose,
  onDownload,
  movieId,
  movieTitle,
}: SeriesDownloadDialogProps) => {
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [seasons, setSeasons] = useState<number[]>([]);
  const [selectedSeason, setSelectedSeason] = useState<number>(1);
  const [selectedQuality, setSelectedQuality] = useState<string>('480p');
  const [selectedEpisodes, setSelectedEpisodes] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(true);
  
  // Ad countdown state
  const [showAdCountdown, setShowAdCountdown] = useState(false);
  const [adCountdown, setAdCountdown] = useState(0);

  useEffect(() => {
    if (isOpen && movieId) {
      fetchEpisodes();
    }
  }, [isOpen, movieId]);

  const fetchEpisodes = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('episodes')
        .select('*')
        .eq('movie_id', movieId)
        .order('season_number')
        .order('episode_number');

      if (error) throw error;

      if (data && data.length > 0) {
        setEpisodes(data);
        const uniqueSeasons = [...new Set(data.map(e => e.season_number))];
        setSeasons(uniqueSeasons);
        setSelectedSeason(uniqueSeasons[0]);
      }
    } catch (error) {
      console.error('Error fetching episodes:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredEpisodes = episodes.filter(e => e.season_number === selectedSeason);

  const getFileSize = (episode: Episode, quality: string) => {
    switch (quality) {
      case '360p': return episode.file_size_360p || '~250 MB';
      case '480p': return episode.file_size_480p || '~500 MB';
      case '720p': return episode.file_size_720p || '~800 MB';
      case '1080p': return episode.file_size_1080p || '~1.5 GB';
      default: return '~500 MB';
    }
  };

  const toggleEpisode = (episodeId: string) => {
    const newSelected = new Set(selectedEpisodes);
    if (newSelected.has(episodeId)) {
      newSelected.delete(episodeId);
    } else {
      newSelected.add(episodeId);
    }
    setSelectedEpisodes(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedEpisodes.size === filteredEpisodes.length) {
      setSelectedEpisodes(new Set());
    } else {
      setSelectedEpisodes(new Set(filteredEpisodes.map(e => e.id)));
    }
  };

  // Handle ad countdown
  useEffect(() => {
    if (showAdCountdown && adCountdown > 0) {
      const timer = setInterval(() => {
        setAdCountdown(prev => prev - 1);
      }, 1000);
      return () => clearInterval(timer);
    } else if (showAdCountdown && adCountdown === 0) {
      // Ad finished, proceed with download
      setShowAdCountdown(false);
      const episodesToDownload = episodes.filter(e => selectedEpisodes.has(e.id));
      onDownload(episodesToDownload, selectedQuality);
    }
  }, [showAdCountdown, adCountdown, episodes, selectedEpisodes, selectedQuality, onDownload]);

  const handleDownload = () => {
    if (selectedEpisodes.size === 0) return;
    
    // Start ad countdown
    const countdown = getAdCountdown(selectedQuality);
    setAdCountdown(countdown);
    setShowAdCountdown(true);
  };

  if (!isOpen) return null;

  // Show ad countdown screen
  if (showAdCountdown) {
    return (
      <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex flex-col items-center justify-center animate-fade-in">
        <div className="text-center px-8">
          <Loader2 size={48} className="text-primary animate-spin mx-auto mb-6" />
          <h2 className="font-display text-2xl text-foreground mb-2">
            OPTIMIZING ASSET ACCESS
          </h2>
          <p className="text-muted-foreground mb-6">
            Secure Protocol Verified
          </p>
          <div className="w-48 h-2 bg-secondary rounded-full mx-auto overflow-hidden">
            <div 
              className="h-full bg-primary transition-all duration-1000"
              style={{ width: `${((getAdCountdown(selectedQuality) - adCountdown) / getAdCountdown(selectedQuality)) * 100}%` }}
            />
          </div>
          <p className="text-sm text-muted-foreground mt-4">
            Starting in {adCountdown} seconds...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex flex-col animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <h2 className="font-display text-xl text-foreground">Download</h2>
        <button
          onClick={onClose}
          className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
        >
          <X size={20} className="text-foreground" />
        </button>
      </div>

      {/* Resources Header */}
      <div className="p-4 glass-card mx-4 mt-4 rounded-xl">
        <p className="text-sm text-muted-foreground mb-3">
          <span className="font-semibold text-foreground">Resources</span> {movieTitle}
        </p>

        {/* Filters */}
        <div className="flex gap-3">
          {/* Season Selector */}
          <Select 
            value={selectedSeason.toString()} 
            onValueChange={(v) => setSelectedSeason(parseInt(v))}
          >
            <SelectTrigger className="w-32 bg-secondary">
              <SelectValue placeholder="Season" />
            </SelectTrigger>
            <SelectContent className="bg-background border-border">
              {seasons.map((season) => (
                <SelectItem key={season} value={season.toString()}>
                  Season {season.toString().padStart(2, '0')}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Quality Selector */}
        <div className="flex gap-2 mt-3">
          {QUALITY_OPTIONS.map((quality) => (
            <button
              key={quality}
              onClick={() => setSelectedQuality(quality)}
              className={cn(
                'px-4 py-2 rounded-lg text-sm font-medium transition-colors',
                selectedQuality === quality
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-muted-foreground hover:text-foreground'
              )}
            >
              {quality.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Episodes List */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filteredEpisodes.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            No episodes available for this season
          </div>
        ) : (
          <div className="space-y-3">
            {filteredEpisodes.map((episode) => (
              <button
                key={episode.id}
                onClick={() => toggleEpisode(episode.id)}
                className={cn(
                  'w-full glass-card p-4 flex items-center gap-4 transition-all',
                  selectedEpisodes.has(episode.id) && 'border-primary bg-primary/10'
                )}
              >
                {/* Checkbox */}
                <div className={cn(
                  'w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors',
                  selectedEpisodes.has(episode.id)
                    ? 'border-primary bg-primary'
                    : 'border-muted-foreground'
                )}>
                  {selectedEpisodes.has(episode.id) && (
                    <Check size={14} className="text-primary-foreground" />
                  )}
                </div>

                {/* Episode Info */}
                <div className="flex-1 text-left">
                  <p className="font-medium text-foreground">
                    S{selectedSeason.toString().padStart(2, '0')} E{episode.episode_number.toString().padStart(2, '0')} · {episode.title || 'Episode'}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {getFileSize(episode, selectedQuality)} | {episode.duration || '~45:00'}
                  </p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-border flex items-center gap-4">
        <button
          onClick={toggleSelectAll}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <div className={cn(
            'w-5 h-5 rounded border-2 flex items-center justify-center transition-colors',
            selectedEpisodes.size === filteredEpisodes.length && filteredEpisodes.length > 0
              ? 'border-primary bg-primary'
              : 'border-muted-foreground'
          )}>
            {selectedEpisodes.size === filteredEpisodes.length && filteredEpisodes.length > 0 && (
              <Check size={12} className="text-primary-foreground" />
            )}
          </div>
          Select All
        </button>

        <button
          onClick={handleDownload}
          disabled={selectedEpisodes.size === 0}
          className={cn(
            'flex-1 btn-gold flex items-center justify-center gap-2',
            selectedEpisodes.size === 0 && 'opacity-50 cursor-not-allowed'
          )}
        >
          <Download size={18} />
          Download ({selectedEpisodes.size})
        </button>
      </div>
    </div>
  );
};
