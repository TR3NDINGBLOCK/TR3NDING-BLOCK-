import { Play, Info, Flame } from 'lucide-react';
import { Movie } from '@/types/movie';
import { useNavigate } from 'react-router-dom';

interface HeroBannerProps {
  movie: Movie;
}

export const HeroBanner = ({ movie }: HeroBannerProps) => {
  const navigate = useNavigate();

  return (
    <section className="relative mx-4 mt-4 rounded-2xl overflow-hidden">
      {/* Background Image */}
      <div className="relative aspect-[4/3] md:aspect-video">
        <img 
          src={movie.thumbnail} 
          alt={movie.title}
          className="w-full h-full object-cover"
        />
        
        {/* Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-transparent" />
      </div>
      
      {/* Content */}
      <div className="absolute inset-0 flex flex-col justify-end p-4 md:p-6">
        {/* Today's Pick Badge */}
        <div className="flex items-center gap-2 mb-2">
          <div className="flex items-center gap-1.5 bg-primary/20 backdrop-blur-sm px-3 py-1 rounded-full border border-primary/30">
            <Flame size={14} className="text-primary" />
            <span className="text-xs font-semibold text-primary tracking-wide">
              TODAY'S PICK
            </span>
          </div>
        </div>
        
        {/* Title */}
        <h1 className="font-display text-3xl md:text-5xl text-foreground leading-tight mb-3">
          {movie.title.toUpperCase()}
        </h1>
        
        {/* Actions */}
        <div className="flex gap-3">
          <button 
            onClick={() => navigate(`/watch/${movie.id}`)}
            className="btn-gold flex items-center gap-2"
          >
            <Play size={18} fill="currentColor" />
            <span className="font-semibold">WATCH NOW</span>
          </button>
          
          <button 
            onClick={() => navigate(`/movie/${movie.id}`)}
            className="btn-glass flex items-center gap-2"
          >
            <Info size={18} />
            <span>DETAILS</span>
          </button>
        </div>
      </div>
    </section>
  );
};
