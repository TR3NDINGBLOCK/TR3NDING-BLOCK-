import { useState } from 'react';
import { Download, X, CheckCircle, Timer } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DownloadQualityDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (quality: string) => void;
  movieTitle: string;
}

const QUALITY_OPTIONS = [
  { value: '360p', label: '360p', size: '~250 MB', adDuration: 3 },
  { value: '720p', label: '720p HD', size: '~800 MB', adDuration: 10 },
  { value: '1080p', label: '1080p Full HD', size: '~1.5 GB', adDuration: 10 },
];

export const DownloadQualityDialog = ({
  isOpen,
  onClose,
  onSelect,
  movieTitle,
}: DownloadQualityDialogProps) => {
  const [selectedQuality, setSelectedQuality] = useState<string | null>(null);
  const [showAd, setShowAd] = useState(false);
  const [adCountdown, setAdCountdown] = useState(0);

  const handleQualitySelect = (quality: string) => {
    setSelectedQuality(quality);
    
    // Determine ad duration based on quality
    const option = QUALITY_OPTIONS.find(q => q.value === quality);
    const adDuration = option?.adDuration || 1;
    
    // Show ad
    setShowAd(true);
    setAdCountdown(adDuration);

    // Countdown
    const interval = setInterval(() => {
      setAdCountdown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          setShowAd(false);
          onSelect(quality);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  if (!isOpen) return null;

  if (showAd) {
    return (
      <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex items-center justify-center animate-fade-in">
        <div className="text-center px-6 max-w-sm">
          {/* Ad Placeholder */}
          <div className="w-full aspect-video bg-gradient-to-br from-primary/20 to-primary/5 rounded-xl border border-primary/30 flex items-center justify-center mb-6">
            <div className="text-center">
              <Timer size={40} className="text-primary mx-auto mb-2 animate-pulse" />
              <p className="text-sm text-muted-foreground">Advertisement</p>
            </div>
          </div>

          {/* Countdown */}
          <div className="flex items-center justify-center gap-2 text-primary">
            <span className="text-4xl font-display gold-glow">{adCountdown}</span>
            <span className="text-sm">seconds remaining</span>
          </div>
          
          <p className="text-xs text-muted-foreground mt-4">
            Your download will start automatically...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex items-center justify-center animate-fade-in">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
      >
        <X size={20} className="text-foreground" />
      </button>

      <div className="px-6 max-w-sm w-full">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 flex items-center justify-center">
            <Download size={32} className="text-primary" />
          </div>
          <h2 className="font-display text-2xl text-foreground mb-1">SELECT QUALITY</h2>
          <p className="text-sm text-muted-foreground truncate">{movieTitle}</p>
        </div>

        {/* Quality Options */}
        <div className="space-y-3">
          {QUALITY_OPTIONS.map((option) => (
            <button
              key={option.value}
              onClick={() => handleQualitySelect(option.value)}
              className={cn(
                'w-full glass-card p-4 flex items-center justify-between transition-all',
                'hover:border-primary/50 hover:bg-primary/5',
                selectedQuality === option.value && 'border-primary bg-primary/10'
              )}
            >
              <div className="flex items-center gap-3">
                <div className={cn(
                  'w-10 h-10 rounded-lg flex items-center justify-center',
                  option.value === '1080p' 
                    ? 'bg-primary/20' 
                    : option.value === '720p'
                      ? 'bg-blue-500/20'
                      : 'bg-secondary'
                )}>
                  {option.value === '1080p' ? (
                    <span className="text-xs font-bold text-primary">HD+</span>
                  ) : option.value === '720p' ? (
                    <span className="text-xs font-bold text-blue-400">HD</span>
                  ) : (
                    <span className="text-xs font-bold text-muted-foreground">SD</span>
                  )}
                </div>
                <div className="text-left">
                  <p className="font-medium text-foreground">{option.label}</p>
                  <p className="text-xs text-muted-foreground">{option.size}</p>
                </div>
              </div>
              
              {option.adDuration > 1 ? (
                <span className="text-xs text-muted-foreground">
                  {option.adDuration}s ad
                </span>
              ) : (
                <span className="text-xs text-primary">
                  {option.adDuration}s ad
                </span>
              )}
            </button>
          ))}
        </div>

        <p className="text-center text-xs text-muted-foreground mt-4">
          Higher quality requires a shorter ad
        </p>
      </div>
    </div>
  );
};
