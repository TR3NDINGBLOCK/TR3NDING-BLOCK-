import { Crown, ExternalLink } from 'lucide-react';
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const AdBanner = () => {
  const [adConfig, setAdConfig] = useState<{ adId: string; appId: string } | null>(null);
  const [adFailed, setAdFailed] = useState(false);

  useEffect(() => {
    const fetchAdConfig = async () => {
      try {
        const { data, error } = await supabase
          .from('app_settings')
          .select('*')
          .in('setting_key', ['admob_ad_id', 'admob_app_id']);

        if (error) throw error;

        if (data && data.length > 0) {
          const config: any = {};
          data.forEach((setting) => {
            if (setting.setting_key === 'admob_ad_id') {
              config.adId = setting.setting_value;
            } else if (setting.setting_key === 'admob_app_id') {
              config.appId = setting.setting_value;
            }
          });
          
          // Only set config if both values exist and are not empty
          if (config.adId && config.appId) {
            setAdConfig(config);
          } else {
            setAdFailed(true);
          }
        } else {
          setAdFailed(true);
        }
      } catch (error) {
        console.error('Ad config fetch failed:', error);
        setAdFailed(true);
      }
    };

    fetchAdConfig();
  }, []);

  // Hide ad container entirely if ad fails to load
  if (adFailed || (!adConfig?.adId || !adConfig?.appId)) {
    return null;
  }

  return (
    <div className="fixed bottom-16 left-0 right-0 z-40 bg-gradient-to-r from-primary/20 via-primary/10 to-primary/20 border-t border-b border-primary/30 px-4 py-2">
      {/* Real ad container (would integrate with AdMob/AdSense SDK) */}
      <div 
        className="flex items-center justify-center gap-2"
        data-ad-id={adConfig.adId}
        data-app-id={adConfig.appId}
      >
        <div className="flex items-center gap-2 text-muted-foreground">
          <ExternalLink size={12} />
          <span className="text-xs">Advertisement</span>
        </div>
      </div>
    </div>
  );
};
