import logoImage from '@/assets/logo.jpg';

interface LoadingScreenProps {
  message?: string;
}

export const LoadingScreen = ({ message = 'Loading...' }: LoadingScreenProps) => {
  return (
    <div className="fixed inset-0 z-[200] bg-background flex flex-col items-center justify-center animate-fade-in">
      {/* Logo */}
      <div className="w-32 h-32 rounded-2xl overflow-hidden gold-glow mb-6 animate-pulse">
        <img 
          src={logoImage} 
          alt="TR3NDING BLOCK" 
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Brand Name */}
      <h1 className="font-display text-2xl gold-gradient-text tracking-wider mb-4">
        TR3NDING BLOCK
      </h1>
      
      {/* Loading Indicator */}
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
        <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
        <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
      </div>
      
      {/* Message */}
      <p className="text-sm text-muted-foreground mt-4">{message}</p>
    </div>
  );
};
