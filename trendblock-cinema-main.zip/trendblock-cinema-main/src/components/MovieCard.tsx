import { Movie } from '@/types/movie';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MovieCardProps {
  movie: Movie;
  onClick?: () => void;
  variant?: 'default' | 'large';
}

export const MovieCard = ({ movie, onClick, variant = 'default' }: MovieCardProps) => {
  return (
    <div 
      className={cn(
        'movie-card cursor-pointer group',
        variant === 'large' ? 'w-40 md:w-48' : 'w-32 md:w-40'
      )}
      onClick={onClick}
    >
      <div className={cn(
        'relative overflow-hidden rounded-xl',
        variant === 'large' ? 'aspect-[2/3]' : 'aspect-[2/3]'
      )}>
        <img 
          src={movie.thumbnail} 
          alt={movie.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-80" />
        
        {/* 4K Badge */}
        {movie.is4K && (
          <span className="badge-4k">4K</span>
        )}
        
        {/* Rating */}
        <div className="absolute bottom-2 left-2 flex items-center gap-1">
          <Star size={12} className="text-primary fill-primary" />
          <span className="text-xs font-semibold text-foreground">{movie.rating}</span>
        </div>
      </div>
      
      <div className="mt-2 px-1">
        <h3 className="text-sm font-medium text-foreground line-clamp-1">
          {movie.title}
        </h3>
        <p className="text-xs text-muted-foreground mt-0.5">
          {movie.releaseYear} • {movie.genre[0]}
        </p>
      </div>
    </div>
  );
};
