import { Shield, CheckCircle, Download, X } from 'lucide-react';
import { useState, useEffect } from 'react';

interface DownloadOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  fileName: string;
  fileSize: string;
  onComplete: () => void;
}

export const DownloadOverlay = ({ isOpen, onClose, fileName, fileSize, onComplete }: DownloadOverlayProps) => {
  const [countdown, setCountdown] = useState(3);
  const [phase, setPhase] = useState<'verifying' | 'ready' | 'downloading'>('verifying');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!isOpen) {
      setCountdown(3);
      setPhase('verifying');
      setProgress(0);
      return;
    }

    // Countdown phase
    if (phase === 'verifying' && countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }

    if (phase === 'verifying' && countdown === 0) {
      setPhase('ready');
      setTimeout(() => setPhase('downloading'), 500);
    }

    // Download phase
    if (phase === 'downloading' && progress < 100) {
      const timer = setTimeout(() => {
        setProgress(prev => Math.min(prev + Math.random() * 15, 100));
      }, 200);
      return () => clearTimeout(timer);
    }

    if (progress >= 100) {
      setTimeout(() => {
        onComplete();
        onClose();
      }, 500);
    }
  }, [isOpen, countdown, phase, progress, onComplete, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex items-center justify-center animate-fade-in">
      <button 
        onClick={onClose}
        className="absolute top-4 right-4 w-10 h-10 rounded-full bg-secondary flex items-center justify-center"
      >
        <X size={20} className="text-foreground" />
      </button>

      <div className="text-center px-6 max-w-sm">
        {/* Icon */}
        <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-primary/20 flex items-center justify-center gold-glow">
          {phase === 'downloading' ? (
            <Download size={40} className="text-primary animate-pulse" />
          ) : (
            <Shield size={40} className="text-primary" />
          )}
        </div>

        {/* Title */}
        <h2 className="font-display text-3xl text-foreground mb-2">
          {phase === 'downloading' ? 'ASSET SYNCHRONIZATION' : 'OPTIMIZING ASSET ACCESS'}
        </h2>

        {/* Status */}
        {phase === 'verifying' && (
          <>
            <div className="flex items-center justify-center gap-2 text-primary mb-4">
              <CheckCircle size={16} className="animate-pulse" />
              <span className="text-sm font-semibold">SECURE PROTOCOL VERIFIED</span>
            </div>
            <div className="text-6xl font-display text-primary gold-glow mb-4">
              {countdown}
            </div>
            <p className="text-muted-foreground text-sm">
              Initializing secure connection...
            </p>
          </>
        )}

        {phase === 'ready' && (
          <div className="flex items-center justify-center gap-2 text-primary">
            <CheckCircle size={20} />
            <span className="font-semibold">PROTOCOL READY</span>
          </div>
        )}

        {phase === 'downloading' && (
          <>
            <p className="text-muted-foreground text-sm mb-6">{fileName}</p>
            
            {/* Progress Bar */}
            <div className="w-full bg-secondary rounded-full h-3 mb-3 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-primary to-gold-light transition-all duration-200 rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <span className="text-primary font-semibold">
                {progress.toFixed(0)}% SYNCHRONIZING
              </span>
              <span className="text-muted-foreground">{fileSize}</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
